import cv2
import numpy as np
from pyzbar.pyzbar import decode

# img = cv2.imread("C:/Users/jaikr/Jupyter Projects/QR code/GitJay.png")
cap = cv2.VideoCapture(0)
cap.set(3, 640)  # set width
cap.set(4, 480)  # set height

def register_qr_code(qr_code, employee_name):
    with open('myDataFile.txt', 'a') as f:
        f.write(f"{qr_code}\t{employee_name}\n")
    myDataList.append(qr_code)  # Add the new QR code to myDataList

with open('myDataFile.txt') as f:
    myDataList = f.read().splitlines()   # every line is a new item 
    print(myDataList)

while True:
    success, img = cap.read()
    for barcode in decode(img):
        myData = barcode.data.decode('utf-8')
        if myData in myDataList:
            # Find associated employee name
            with open('myDataFile.txt', 'r') as f:
                lines = f.readlines()
                for line in lines:
                    qr_code, employee_name = line.strip().split('\t')
                    if qr_code == myData:
                        employee_name = employee_name
                        break
            myOutput = employee_name
            myColor = (255, 0, 255)  # Magenta for authorized

        else:
            myOutput = "Unauthorized"
            myColor = (0, 0, 255)

            # Check if the QR code is already registered
            if myData not in myDataList:
                # Prompt user for employee name and register QR code
                employee_name = input("Enter employee name for registration: ")
                register_qr_code(myData, employee_name)
                myDataList.append(myData)  # Update myDataList with the new QR code

        pts = np.array([barcode.polygon], np.int32)
        pts = pts.reshape((-1, 1, 2))
        cv2.polylines(img, [pts], True, myColor, 5)
        pts2 = barcode.rect
        cv2.putText(img, myOutput, (pts2[0], pts2[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255,0,0), 2)

    cv2.imshow('Result', img)
    cv2.waitKey(1)
